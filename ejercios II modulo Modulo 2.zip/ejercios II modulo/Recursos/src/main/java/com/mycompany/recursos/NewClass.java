
package com.mycompany.recursos;

public class NewClass {
    
}
